# GrowthPilot beta currently has no custom ProGuard rules.
