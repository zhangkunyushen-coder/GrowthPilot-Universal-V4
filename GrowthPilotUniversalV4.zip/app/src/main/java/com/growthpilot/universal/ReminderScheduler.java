package com.growthpilot.universal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Calendar;

public class ReminderScheduler {
    public static void scheduleAll(Context c) {
        SharedPreferences sp = c.getSharedPreferences(AppStore.PREFS, Context.MODE_PRIVATE);
        schedule(c,"morning",301,sp.getInt("morning_hour",7),sp.getInt("morning_min",30));
        schedule(c,"action",302,sp.getInt("action_hour",19),sp.getInt("action_min",30));
        schedule(c,"review",303,sp.getInt("review_hour",22),sp.getInt("review_min",30));
    }

    private static void schedule(Context c, String type, int code, int hour, int minute) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, AlarmReceiver.class); i.putExtra("type",type);
        PendingIntent pi = PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar next = Calendar.getInstance(); next.set(Calendar.HOUR_OF_DAY,hour); next.set(Calendar.MINUTE,minute); next.set(Calendar.SECOND,0); next.set(Calendar.MILLISECOND,0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
}
