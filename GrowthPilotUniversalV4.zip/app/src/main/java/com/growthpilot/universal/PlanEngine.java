package com.growthpilot.universal;

import android.content.Context;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class PlanEngine {
    private final AppStore store;

    public PlanEngine(Context c) { store = new AppStore(c); }

    public String[] phases(Goal g) {
        String c = g.category == null ? "" : g.category;
        if (c.contains("考试") || c.contains("语言") || c.contains("学习")) {
            return new String[]{"评估建档", "基础补齐", "专项强化", "综合训练", "冲刺验收"};
        }
        if (c.contains("编程") || c.contains("项目") || c.contains("技术")) {
            return new String[]{"范围定义", "基础能力", "核心实现", "联调实战", "交付优化"};
        }
        if (c.contains("运动") || c.contains("健身") || c.contains("健康")) {
            return new String[]{"基线评估", "建立习惯", "渐进训练", "专项强化", "巩固保持"};
        }
        if (c.contains("职业") || c.contains("求职")) {
            return new String[]{"目标画像", "能力补齐", "作品证明", "实战投递", "复盘迭代"};
        }
        return new String[]{"目标澄清", "打好基础", "集中攻克", "实战验证", "完成复盘"};
    }

    public String currentPhase(Goal g) {
        String[] p = phases(g);
        return p[Math.max(0, Math.min(p.length - 1, g.phaseIndex))];
    }

    public int totalProgress(Goal g) {
        int base = g.phaseIndex * 20;
        int within = Math.min(20, Math.max(0, g.phaseProgress) / 5);
        if (g.phaseIndex >= 4 && g.phaseProgress >= 100) return 100;
        return Math.min(99, base + within);
    }

    public long daysLeft(Goal g) {
        try {
            return Math.max(0, ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(g.targetDate)));
        } catch (Exception e) { return -1; }
    }

    public int expectedProgress(Goal g) {
        try {
            LocalDate created = java.time.Instant.ofEpochMilli(g.createdAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            LocalDate target = LocalDate.parse(g.targetDate);
            long total = Math.max(1, ChronoUnit.DAYS.between(created, target));
            long used = Math.max(0, ChronoUnit.DAYS.between(created, LocalDate.now()));
            return Math.max(0, Math.min(100, (int)(used * 100 / total)));
        } catch (Exception e) { return totalProgress(g); }
    }

    public int healthScore(Goal g) {
        int actual = totalProgress(g);
        int expected = expectedProgress(g);
        int pace = 70 + (actual - expected);
        int adherence = store.recentAverageCompletion(7);
        int phaseSignal = Math.min(100, 55 + g.phaseProgress / 2);
        int score = (pace * 45 + adherence * 35 + phaseSignal * 20) / 100;
        return Math.max(10, Math.min(100, score));
    }

    public String healthLabel(Goal g) {
        int h = healthScore(g);
        if (h >= 80) return "稳健";
        if (h >= 60) return "可控";
        if (h >= 40) return "有风险";
        return "需要重排";
    }

    public List<TaskItem> buildTodayTasks() {
        List<Goal> active = new ArrayList<>();
        for (Goal g : store.goals()) if (g.active) active.add(g);
        if (active.isEmpty()) return new ArrayList<>();
        Collections.sort(active, Comparator.comparingInt((Goal g) -> g.priority).reversed());

        int capacity = store.dailyCapacity();
        int prioritySum = 0;
        for (Goal g : active) prioritySum += Math.max(1, g.priority);
        int recent = store.recentAverageCompletion(3);
        double adaptive = recent < 50 ? 0.78 : recent >= 85 ? 1.08 : 1.0;
        int usable = Math.max(30, (int)(capacity * 0.80 * adaptive));

        List<TaskItem> out = new ArrayList<>();
        int daySeed = LocalDate.now().getDayOfYear();
        for (Goal g : active) {
            int share = Math.max(20, usable * Math.max(1, g.priority) / Math.max(1, prioritySum));
            int planned = Math.min(Math.max(20, share), Math.max(20, g.dailyMinutes));
            out.add(coreTask(g, planned, daySeed));
            if (planned >= 70 && out.size() < 5) out.add(reinforcementTask(g, Math.max(15, planned / 3), daySeed));
            if (out.size() >= 6) break;
        }
        return out;
    }

    private TaskItem coreTask(Goal g, int minutes, int seed) {
        String phase = currentPhase(g);
        String title;
        String guide;
        String min;
        int weight = 7;
        int idx = g.phaseIndex;
        String c = g.category == null ? "" : g.category;

        if (c.contains("语言") || c.contains("考试") || c.contains("学习")) {
            String[] titles = {"做一次基线诊断并列出3个薄弱点", "补齐一个高频基础模块", "攻克一个最弱专项", "完成一组限时综合训练", "完成一次模拟 + 错题闭环"};
            title = titles[idx];
            guide = studyGuide(g, phase, idx, minutes);
            min = "最低行动：只做 15 分钟闭卷回忆 + 5 道题，并记录错因。";
        } else if (c.contains("编程") || c.contains("项目") || c.contains("技术")) {
            String[] titles = {"定义今天的可交付结果", "完成一个基础能力实验", "实现一个核心功能闭环", "做一次真实联调/测试", "修复最高优先级问题并交付"};
            title = titles[idx];
            guide = projectGuide(g, phase, idx, minutes);
            min = "最低行动：打开项目，解决一个最小问题，并留下代码/日志/截图中的一种证据。";
        } else if (c.contains("运动") || c.contains("健身") || c.contains("健康")) {
            String[] titles = {"记录基线并完成轻量训练", "完成一次可持续训练", "按渐进原则完成主训练", "完成专项训练 + 数据记录", "巩固习惯并复盘恢复"};
            title = titles[idx];
            guide = fitnessGuide(g, phase, idx, minutes);
            min = "最低行动：10 分钟快走/活动 + 5 分钟基础力量，不断链。";
        } else if (c.contains("职业") || c.contains("求职")) {
            String[] titles = {"明确目标岗位与能力差距", "补一个关键能力", "产出一个可展示成果", "完成一次模拟/投递实战", "复盘反馈并迭代材料"};
            title = titles[idx];
            guide = careerGuide(g, phase, idx, minutes);
            min = "最低行动：完成一个 15 分钟可验证动作，例如改一段简历或投递1个岗位。";
        } else {
            String[] titles = {"把目标拆成可验证结果", "完成一个基础动作", "攻克当前最大瓶颈", "做一次真实情境验证", "完成收尾并复盘"};
            title = titles[idx];
            guide = genericGuide(g, phase, idx, minutes);
            min = "最低行动：做一个 15 分钟、能留下结果的最小动作。";
        }

        String id = g.id + "_core_" + LocalDate.now() + "_" + idx;
        return new TaskItem(id, g.id, g.title, title, minutes, guide, min, weight);
    }

    private TaskItem reinforcementTask(Goal g, int minutes, int seed) {
        String title = (seed % 2 == 0) ? "复盘 + 主动回忆/复测" : "输出成果 + 查漏补缺";
        String guide = "【目的】把今天的输入变成可验证的输出。\n\n" +
                "1. 不看资料，写下今天学到/做到的 3 个关键点。\n" +
                "2. 用题目、演示、跑一次流程或向别人讲解来验证。\n" +
                "3. 记录一个仍然卡住的问题。\n" +
                "4. 明天第一步必须针对这个卡点。\n\n" +
                "【验收】至少留下一份可以回看的证据：答案、代码、照片、数据、录音、作品或复盘。";
        String min = "最低行动：写出 3 条主动回忆 + 1 条明日第一步。";
        return new TaskItem(g.id + "_reinforce_" + LocalDate.now(), g.id, g.title, title, minutes, guide, min, 4);
    }

    private String studyGuide(Goal g, String phase, int idx, int minutes) {
        if (idx == 0) return baseHeader(g, phase, minutes) +
                "1. 做 15–20 分钟不查资料的诊断题。\n2. 把错误分成：不会、混淆、速度慢、粗心。\n3. 只选排名前3的薄弱点。\n4. 为每个薄弱点写一个可量化指标。\n\n【验收】你能说清当前水平、前三弱项、下一阶段的提升标准。";
        if (idx == 1) return baseHeader(g, phase, minutes) +
                "1. 用 10 分钟主动回忆旧知识。\n2. 25–40 分钟补一个基础模块。\n3. 立刻做 5–15 道对应题。\n4. 把错题原因写在答案旁边。\n\n【验收】当日小测正确率 ≥70%，并能口头解释关键概念。";
        if (idx == 2) return baseHeader(g, phase, minutes) +
                "1. 先做一次限时专项。\n2. 统计正确率和平均耗时。\n3. 针对最主要错因做针对性训练。\n4. 20 分钟后复测同类题。\n\n【验收】正确率或速度至少有一项改善，并保留前后对比。";
        if (idx == 3) return baseHeader(g, phase, minutes) +
                "1. 按正式节奏完成一组综合任务。\n2. 中途不查答案。\n3. 结束后先自己定位错误，再看解析。\n4. 把错误归因到具体能力模块。\n\n【验收】完成整组训练，能指出失分结构而不是只看总分。";
        return baseHeader(g, phase, minutes) +
                "1. 按正式条件完成模拟。\n2. 统计总分、分项、耗时和放弃题。\n3. 只修复高频错因，不再无限扩充资料。\n4. 给下一次模拟设一个明确提升目标。\n\n【验收】形成“模拟→分析→修复→复测”闭环。";
    }

    private String projectGuide(Goal g, String phase, int idx, int minutes) {
        if (idx == 0) return baseHeader(g, phase, minutes) +
                "1. 用一句话定义今天结束时必须能展示的东西。\n2. 列出输入、输出、依赖、风险。\n3. 把任务拆到 30–60 分钟粒度。\n4. 建立最小可运行版本。\n\n【验收】别人能看懂今天的交付物是什么，以及成功标准。";
        if (idx == 1) return baseHeader(g, phase, minutes) +
                "1. 只选一个基础能力做最小实验。\n2. 先验证环境/接口，再加业务逻辑。\n3. 记录输入、输出和异常。\n4. 保存一个干净可复现版本。\n\n【验收】从零重跑一次仍能成功，并有日志或截图证明。";
        if (idx == 2) return baseHeader(g, phase, minutes) +
                "1. 先画数据流/模块关系。\n2. 实现最短闭环：输入→处理→输出。\n3. 正常路径跑通后再处理边界情况。\n4. 一次只改变一个变量。\n\n【验收】核心功能可演示，失败时能定位到具体模块。";
        if (idx == 3) return baseHeader(g, phase, minutes) +
                "1. 用真实数据/设备/用户流程测试。\n2. 记录失败条件，不凭感觉调。\n3. 优先修复可复现、高影响问题。\n4. 每次修改前后做对比。\n\n【验收】至少 3 次可复现测试，并形成问题→假设→修改→结果记录。";
        return baseHeader(g, phase, minutes) +
                "1. 整理最高优先级缺陷。\n2. 做一次完整演示/交付检查。\n3. 补齐 README、使用说明、关键决策。\n4. 输出版本号并冻结基线。\n\n【验收】新用户按说明可运行/使用，核心路径无阻断问题。";
    }

    private String fitnessGuide(Goal g, String phase, int idx, int minutes) {
        if (idx == 0) return baseHeader(g, phase, minutes) +
                "1. 记录体重/围度/基础能力或当前状态。\n2. 做低强度测试，不追求极限。\n3. 记录睡眠、疼痛和主观疲劳。\n\n【验收】有一组之后能重复测量的基线数据。";
        if (idx == 1) return baseHeader(g, phase, minutes) +
                "1. 先做 5 分钟热身。\n2. 主训练保持中等强度，结束时仍有余力。\n3. 记录时长/组数/次数。\n\n【验收】本周能稳定完成计划，不以一次练爆为目标。";
        if (idx == 2) return baseHeader(g, phase, minutes) +
                "1. 比上周只增加一个变量：次数、组数、距离或负荷。\n2. 保留恢复日。\n3. 训练后记录主观强度。\n\n【验收】主要指标逐步提高，疼痛或疲劳没有持续恶化。";
        if (idx == 3) return baseHeader(g, phase, minutes) +
                "1. 根据目标选择专项刺激。\n2. 保留基础力量/有氧。\n3. 每 1–2 周复测关键指标。\n\n【验收】专项指标有可测量改善，而不是只看体重。";
        return baseHeader(g, phase, minutes) +
                "1. 把训练缩成可长期维持的最低周计划。\n2. 找到最容易中断的情境并预设替代方案。\n3. 每月复测一次。\n\n【验收】连续执行稳定，偶尔中断也能在48小时内恢复。";
    }

    private String careerGuide(Goal g, String phase, int idx, int minutes) {
        return baseHeader(g, phase, minutes) +
                "1. 把目标岗位/成果标准写清。\n2. 今天只推进一个能留下证据的动作。\n3. 用作品、数据、面试反馈或投递结果验证。\n4. 结束时写明下一步。\n\n【验收】不是“看了很多”，而是有一项可以展示或验证的产出。";
    }

    private String genericGuide(Goal g, String phase, int idx, int minutes) {
        return baseHeader(g, phase, minutes) +
                "1. 写下今天结束时的可见结果。\n2. 把第一步压缩到 5 分钟内能开始。\n3. 用一个专注块完成最重要部分。\n4. 留下证据并记录卡点。\n\n【验收】有一个外部可见的结果，而不只是“花了时间”。";
    }

    private String baseHeader(Goal g, String phase, int minutes) {
        return "【目标】" + g.title + "\n【当前阶段】" + phase + "\n【计划时长】约 " + minutes + " 分钟\n【为什么】" +
                (g.why == null || g.why.trim().isEmpty() ? "用可验证结果推进目标。" : g.why) + "\n\n";
    }

    public String suggestedSchedule(List<TaskItem> tasks) {
        if (tasks == null || tasks.isEmpty()) return "今天暂无任务。";
        java.util.Map<String,Integer> cursor = new java.util.HashMap<>();
        cursor.put("早晨", 7*60+30); cursor.put("上午", 9*60+30); cursor.put("下午", 14*60+30);
        cursor.put("晚间", 19*60); cursor.put("灵活安排", 20*60+30);
        StringBuilder sb = new StringBuilder();
        for (TaskItem t : tasks) {
            Goal g = store.goalById(t.goalId);
            String pref = g == null ? "灵活安排" : g.preferredTime;
            int start = cursor.containsKey(pref) ? cursor.get(pref) : 20*60+30;
            int end = start + t.minutes;
            sb.append(time(start)).append("–").append(time(end)).append("  ").append(t.title).append("\n");
            cursor.put(pref, end + 10);
        }
        sb.append("\n建议保留约20%时间做缓冲；临时有事时先保核心任务，不用把计划补到深夜。");
        return sb.toString().trim();
    }

    private String time(int minuteOfDay) {
        int m = Math.max(0, minuteOfDay);
        int h = (m / 60) % 24;
        int min = m % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", h, min);
    }

    public String stuckAdvice(TaskItem t, String reason) {
        if (reason.contains("不知道")) return "把任务缩到第一个 5 分钟动作：打开资料/工程，只完成准备步骤，然后再决定是否继续。\n\n" + t.minimumAction;
        if (reason.contains("太难")) return "先做一个低难度示例或最小实验，记录你具体卡在哪一行/哪一步。不要同时解决多个问题。\n\n" + t.minimumAction;
        if (reason.contains("没时间")) return "今天切换到最低行动版本。完成后保留连续性，剩余任务自动留给后续计划，而不是硬补到深夜。\n\n" + t.minimumAction;
        if (reason.contains("没动力")) return "不要等动力。设置 10 分钟计时，只承诺做 10 分钟；完成后允许停止。重点是恢复启动能力。\n\n" + t.minimumAction;
        if (reason.contains("疲劳")) return "降低难度而不是硬撑。优先完成复盘、整理、轻量练习或恢复任务；如果出现明显身体不适，停止训练并评估。";
        return "把问题写成：预期是什么、实际是什么、已经试过什么。然后只验证一个最可能的原因。\n\n" + t.minimumAction;
    }

    public String dailyCoachMessage() {
        int recent = store.recentAverageCompletion(3);
        int energy = store.energyToday();
        if (recent < 50) return "最近完成率偏低：今天自动减少任务密度，先保证最重要目标不断链。";
        if (recent >= 85 && energy >= 3) return "最近执行稳定：保持核心任务，并用一次复测/输出验证真实进步。";
        if (energy <= 2) return "今天精力偏低：优先核心任务，非关键任务使用最低行动版本。";
        return "今天按优先级推进：先完成最重要目标，再用剩余时间补强化任务。";
    }
}
