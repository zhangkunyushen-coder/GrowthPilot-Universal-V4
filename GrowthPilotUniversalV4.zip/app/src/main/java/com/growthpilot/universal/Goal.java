package com.growthpilot.universal;

import org.json.JSONException;
import org.json.JSONObject;

public class Goal {
    public String id;
    public String title;
    public String category;
    public String targetDate;
    public String why;
    public String baseline;
    public int dailyMinutes;
    public int priority;
    public String preferredTime;
    public int phaseIndex;
    public int phaseProgress;
    public long createdAt;
    public boolean active;

    public Goal() {}

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("category", category);
        o.put("targetDate", targetDate);
        o.put("why", why);
        o.put("baseline", baseline);
        o.put("dailyMinutes", dailyMinutes);
        o.put("priority", priority);
        o.put("preferredTime", preferredTime);
        o.put("phaseIndex", phaseIndex);
        o.put("phaseProgress", phaseProgress);
        o.put("createdAt", createdAt);
        o.put("active", active);
        return o;
    }

    public static Goal fromJson(JSONObject o) {
        Goal g = new Goal();
        g.id = o.optString("id", "g" + System.currentTimeMillis());
        g.title = o.optString("title", "未命名目标");
        g.category = o.optString("category", "通用目标");
        g.targetDate = o.optString("targetDate", "");
        g.why = o.optString("why", "");
        g.baseline = o.optString("baseline", "");
        g.dailyMinutes = Math.max(15, o.optInt("dailyMinutes", 60));
        g.priority = Math.max(1, Math.min(5, o.optInt("priority", 3)));
        g.preferredTime = o.optString("preferredTime", "晚间");
        g.phaseIndex = Math.max(0, Math.min(4, o.optInt("phaseIndex", 0)));
        g.phaseProgress = Math.max(0, Math.min(100, o.optInt("phaseProgress", 0)));
        g.createdAt = o.optLong("createdAt", System.currentTimeMillis());
        g.active = o.optBoolean("active", true);
        return g;
    }
}
