package com.growthpilot.universal;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class AppStore {
    public static final String PREFS = "growthpilot_universal_v4";
    private final SharedPreferences sp;
    private final SimpleDateFormat dayFmt = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());

    public AppStore(Context c) {
        sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public SharedPreferences prefs() { return sp; }

    public boolean onboarded() { return sp.getBoolean("onboarded", false); }
    public void setOnboarded(boolean b) { sp.edit().putBoolean("onboarded", b).apply(); }
    public String userName() { return sp.getString("user_name", ""); }
    public void setUserName(String s) { sp.edit().putString("user_name", s == null ? "" : s.trim()).apply(); }

    public int dailyCapacity() { return sp.getInt("daily_capacity", 150); }
    public void setDailyCapacity(int m) { sp.edit().putInt("daily_capacity", Math.max(30, Math.min(720, m))).apply(); }

    public List<Goal> goals() {
        List<Goal> out = new ArrayList<>();
        String raw = sp.getString("goals_json", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) out.add(Goal.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public void saveGoals(List<Goal> goals) {
        JSONArray a = new JSONArray();
        for (Goal g : goals) {
            try { a.put(g.toJson()); } catch (JSONException ignored) {}
        }
        sp.edit().putString("goals_json", a.toString()).apply();
    }

    public Goal goalById(String id) {
        for (Goal g : goals()) if (g.id.equals(id)) return g;
        return null;
    }

    public Goal addGoal(String title, String category, String targetDate, String why, String baseline,
                        int dailyMinutes, int priority, String preferredTime) {
        List<Goal> gs = goals();
        Goal g = new Goal();
        g.id = UUID.randomUUID().toString();
        g.title = title.trim();
        g.category = category;
        g.targetDate = targetDate;
        g.why = why.trim();
        g.baseline = baseline.trim();
        g.dailyMinutes = Math.max(15, dailyMinutes);
        g.priority = Math.max(1, Math.min(5, priority));
        g.preferredTime = preferredTime;
        g.phaseIndex = 0;
        g.phaseProgress = 0;
        g.createdAt = System.currentTimeMillis();
        g.active = true;
        gs.add(g);
        saveGoals(gs);
        return g;
    }

    public void updateGoal(Goal changed) {
        List<Goal> gs = goals();
        for (int i = 0; i < gs.size(); i++) if (gs.get(i).id.equals(changed.id)) gs.set(i, changed);
        saveGoals(gs);
    }

    public void deleteGoal(String id) {
        List<Goal> gs = goals();
        gs.removeIf(g -> g.id.equals(id));
        saveGoals(gs);
    }

    public String todayKey() { return dayFmt.format(new Date()); }

    public boolean isTaskDone(String taskId) {
        return sp.getBoolean("done_" + todayKey() + "_" + taskId, false);
    }

    public void setTaskDone(TaskItem t, int qualityPercent) {
        String k = "done_" + todayKey() + "_" + t.id;
        if (sp.getBoolean(k, false)) return;
        int q = Math.max(50, Math.min(120, qualityPercent));
        sp.edit().putBoolean(k, true)
                .putInt("quality_" + todayKey() + "_" + t.id, q)
                .apply();
        addXp(Math.max(5, t.progressWeight * q / 25));
        bumpGoalProgress(t.goalId, Math.max(1, t.progressWeight * q / 100));
    }

    public void undoTask(TaskItem t) {
        sp.edit().remove("done_" + todayKey() + "_" + t.id).apply();
    }

    private void bumpGoalProgress(String goalId, int delta) {
        Goal g = goalById(goalId);
        if (g == null) return;
        g.phaseProgress = Math.min(85, g.phaseProgress + Math.max(1, delta));
        updateGoal(g);
    }

    public void advancePhase(String goalId, int selfScore, String evidence) {
        Goal g = goalById(goalId);
        if (g == null) return;
        if (selfScore >= 70 && g.phaseProgress >= 50) {
            if (g.phaseIndex < 4) {
                g.phaseIndex += 1;
                g.phaseProgress = 0;
            } else {
                g.phaseProgress = 100;
            }
            updateGoal(g);
            addXp(120);
        }
        sp.edit().putString("evidence_" + goalId + "_" + g.phaseIndex, evidence == null ? "" : evidence).apply();
    }

    public int xp() { return sp.getInt("xp", 0); }
    public void addXp(int x) { sp.edit().putInt("xp", Math.max(0, xp() + x)).apply(); }
    public int level() { return 1 + xp() / 200; }
    public int xpToNext() { int r = xp() % 200; return r == 0 ? 200 : 200 - r; }

    public int focusMinutesTotal() { return sp.getInt("focus_total", 0); }
    public int focusMinutesToday() { return sp.getInt("focus_" + todayKey(), 0); }
    public void addFocusMinutes(int m) {
        sp.edit().putInt("focus_total", focusMinutesTotal() + m)
                .putInt("focus_" + todayKey(), focusMinutesToday() + m)
                .apply();
        addXp(Math.max(1, m / 5));
    }

    public void saveDailyReview(String best, String blocker, String firstStep, int energy) {
        String p = "review_" + todayKey() + "_";
        sp.edit().putString(p + "best", best)
                .putString(p + "blocker", blocker)
                .putString(p + "first", firstStep)
                .putInt(p + "energy", energy).apply();
    }

    public String review(String field) { return sp.getString("review_" + todayKey() + "_" + field, ""); }
    public int energyToday() { return sp.getInt("review_" + todayKey() + "_energy", 3); }

    public void saveTodayTotals(int total, int done) {
        sp.edit().putInt("total_" + todayKey(), total).putInt("doneCount_" + todayKey(), done).apply();
    }

    public int completionRateForDay(Calendar c) {
        String d = dayFmt.format(c.getTime());
        int total = sp.getInt("total_" + d, 0);
        int done = sp.getInt("doneCount_" + d, 0);
        if (total <= 0) return -1;
        return Math.max(0, Math.min(100, done * 100 / total));
    }

    public int recentAverageCompletion(int days) {
        Calendar c = Calendar.getInstance();
        int sum = 0, n = 0;
        for (int i = 0; i < days; i++) {
            int r = completionRateForDay(c);
            if (r >= 0) { sum += r; n++; }
            c.add(Calendar.DAY_OF_YEAR, -1);
        }
        return n == 0 ? 65 : sum / n;
    }

    public int streak() {
        Calendar c = Calendar.getInstance();
        int streak = 0;
        for (int i = 0; i < 120; i++) {
            int r = completionRateForDay(c);
            if (r >= 50) streak++;
            else if (i == 0 && r < 0) { }
            else break;
            c.add(Calendar.DAY_OF_YEAR, -1);
        }
        return streak;
    }

    public String exportJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("version", 4);
            o.put("user_name", userName());
            o.put("daily_capacity", dailyCapacity());
            o.put("goals", new JSONArray(sp.getString("goals_json", "[]")));
            o.put("xp", xp());
            o.put("focus_total", focusMinutesTotal());
        } catch (JSONException ignored) {}
        return o.toString();
    }

    public boolean importJson(String raw) {
        try {
            JSONObject o = new JSONObject(raw);
            JSONArray goals = o.getJSONArray("goals");
            sp.edit().putString("user_name", o.optString("user_name", ""))
                    .putInt("daily_capacity", o.optInt("daily_capacity", 150))
                    .putString("goals_json", goals.toString())
                    .putInt("xp", o.optInt("xp", 0))
                    .putInt("focus_total", o.optInt("focus_total", 0))
                    .putBoolean("onboarded", true).apply();
            return true;
        } catch (Exception e) { return false; }
    }
}
