package com.growthpilot.universal;

public class TaskItem {
    public final String id;
    public final String goalId;
    public final String goalTitle;
    public final String title;
    public final int minutes;
    public final String guidance;
    public final String minimumAction;
    public final int progressWeight;

    public TaskItem(String id, String goalId, String goalTitle, String title, int minutes,
                    String guidance, String minimumAction, int progressWeight) {
        this.id = id;
        this.goalId = goalId;
        this.goalTitle = goalTitle;
        this.title = title;
        this.minutes = minutes;
        this.guidance = guidance;
        this.minimumAction = minimumAction;
        this.progressWeight = progressWeight;
    }
}
