package com.growthpilot.universal;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Locale;

public class FocusActivity extends Activity {
    private TextView timeText;
    private TextView statusText;
    private ProgressBar progress;
    private CountDownTimer timer;
    private long totalMs = 25 * 60_000L;
    private long remainingMs = totalMs;
    private boolean running = false;
    private String taskTitle;
    private String taskId;
    private String goalTitle;
    private AppStore store;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new AppStore(this);
        taskTitle = getIntent().getStringExtra("taskTitle");
        taskId = getIntent().getStringExtra("taskId");
        goalTitle = getIntent().getStringExtra("goalTitle");
        if (taskTitle == null) taskTitle = "专注任务";
        if (goalTitle == null) goalTitle = "当前目标";
        render();
    }

    private void render() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this,20), Ui.dp(this,24), Ui.dp(this,20), Ui.dp(this,24));
        root.setBackgroundColor(Color.rgb(15,23,42));

        TextView title = Ui.text(this, "番茄专注", 27, Color.WHITE, true);
        root.addView(title);
        root.addView(Ui.text(this, goalTitle + " · " + taskTitle, 14, Color.rgb(203,213,225), false));

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presets.setPadding(0, Ui.dp(this,18), 0, Ui.dp(this,12));
        presets.addView(preset("15分钟", 15));
        presets.addView(preset("25分钟", 25));
        presets.addView(preset("50分钟", 50));
        root.addView(presets);

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(0, Ui.dp(this,30),0, Ui.dp(this,24));
        timeText = Ui.text(this, format(remainingMs), 54, Color.WHITE, true);
        center.addView(timeText);
        statusText = Ui.text(this, "准备开始 · 一次只做一件事", 14, Color.rgb(148,163,184), false);
        statusText.setGravity(Gravity.CENTER);
        center.addView(statusText);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        progress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this,14));
        pp.setMargins(0, Ui.dp(this,24),0,0);
        center.addView(progress, pp);
        root.addView(center, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f));

        Button start = new Button(this);
        start.setText("开始 / 暂停");
        start.setAllCaps(false);
        start.setOnClickListener(v -> toggle());
        root.addView(start);

        Button finish = new Button(this);
        finish.setText("提前结束并记录本轮");
        finish.setAllCaps(false);
        finish.setOnClickListener(v -> finishSession(false));
        root.addView(finish);

        Button back = new Button(this);
        back.setText("返回");
        back.setAllCaps(false);
        back.setOnClickListener(v -> finish());
        root.addView(back);

        setContentView(root);
    }

    private Button preset(String label, int mins) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            if (timer != null) timer.cancel();
            running = false;
            totalMs = mins * 60_000L;
            remainingMs = totalMs;
            if (timeText != null) timeText.setText(format(remainingMs));
            if (progress != null) progress.setProgress(0);
            if (statusText != null) statusText.setText("已选择 " + mins + " 分钟");
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(this,50),1f);
        p.setMargins(Ui.dp(this,3),0,Ui.dp(this,3),0);
        b.setLayoutParams(p);
        return b;
    }

    private void toggle() {
        if (running) {
            if (timer != null) timer.cancel();
            running = false;
            statusText.setText("已暂停 · 处理完干扰再继续");
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            return;
        }
        running = true;
        statusText.setText("专注中 · 不切换任务");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        timer = new CountDownTimer(remainingMs, 1000) {
            @Override public void onTick(long ms) {
                remainingMs = ms;
                timeText.setText(format(ms));
                int done = (int)((totalMs - ms) * 1000 / Math.max(1,totalMs));
                progress.setProgress(done);
            }
            @Override public void onFinish() {
                remainingMs = 0;
                running = false;
                timeText.setText("00:00");
                progress.setProgress(1000);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                finishSession(true);
            }
        }.start();
    }

    private void finishSession(boolean completedTimer) {
        if (timer != null) timer.cancel();
        running = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        long elapsed = totalMs - remainingMs;
        int mins = (int)Math.max(1, elapsed / 60_000L);
        if (completedTimer) mins = (int)(totalMs / 60_000L);
        final int recorded = mins;

        new AlertDialog.Builder(this)
                .setTitle(completedTimer ? "专注完成 🎯" : "记录本轮专注")
                .setMessage("本轮专注约 " + recorded + " 分钟。\n\n这次是否完成了预定目标？")
                .setPositiveButton("完成了", (d,w) -> {
                    store.addFocusMinutes(recorded);
                    store.addXp(10);
                    setResult(RESULT_OK);
                    finish();
                })
                .setNeutralButton("部分完成", (d,w) -> {
                    store.addFocusMinutes(recorded);
                    store.addXp(4);
                    setResult(RESULT_OK);
                    finish();
                })
                .setNegativeButton("不记录", null)
                .show();
    }

    private String format(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(Locale.getDefault(), "%02d:%02d", sec/60, sec%60);
    }

    @Override protected void onDestroy() {
        if (timer != null) timer.cancel();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
}
