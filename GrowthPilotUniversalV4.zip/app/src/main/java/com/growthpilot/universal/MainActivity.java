package com.growthpilot.universal;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private AppStore store;
    private PlanEngine engine;
    private LinearLayout page;
    private List<TaskItem> todayTasks = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new AppStore(this);
        engine = new PlanEngine(this);
        AlarmReceiver.createChannel(this);
        requestNotifications();
        ReminderScheduler.scheduleAll(this);
        if (!store.onboarded() || store.goals().isEmpty()) showOnboarding(); else showToday();
    }

    @Override protected void onResume() {
        super.onResume();
        engine = new PlanEngine(this);
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        }
    }

    private void shell(String title, String subtitle, boolean nav) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(246,248,252));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(Ui.dp(this,20), Ui.dp(this,18), Ui.dp(this,20), Ui.dp(this,16));
        header.setBackgroundColor(Color.rgb(15,23,42));
        header.addView(Ui.text(this, title, 26, Color.WHITE, true));
        header.addView(Ui.text(this, subtitle, 13, Color.rgb(203,213,225), false));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(Ui.dp(this,14), Ui.dp(this,14), Ui.dp(this,14), Ui.dp(this,28));
        scroll.addView(page);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));
        if (nav) root.addView(navBar());
        setContentView(root);
    }

    private View navBar() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setBackgroundColor(Color.WHITE);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,7));
        addNav(row,"今日",v->showToday());
        addNav(row,"目标",v->showGoals());
        addNav(row,"专注",v->showFocusHub());
        addNav(row,"复盘",v->showReview());
        addNav(row,"数据",v->showStats());
        addNav(row,"设置",v->showSettings());
        hsv.addView(row);
        return hsv;
    }

    private void addNav(LinearLayout row, String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(14); b.setAllCaps(false); b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this,74), Ui.dp(this,48));
        p.setMargins(Ui.dp(this,2),0,Ui.dp(this,2),0);
        row.addView(b,p);
    }

    private void showOnboarding() {
        shell("欢迎来到 GrowthPilot", "把“我想做到”变成每天真正能执行的下一步", false);
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.text(this,"先建立第一个目标",21,Color.rgb(15,23,42),true));
        intro.addView(Ui.text(this,"GrowthPilot 会根据目标、截止日期、可投入时间和你的执行反馈，生成阶段计划、每日行动、详细指导、专注计时和可视化进度。",14,Color.rgb(71,85,105),false));
        page.addView(intro, Ui.cardParams(this));

        EditText name = field("你的称呼（可选）", InputType.TYPE_CLASS_TEXT);
        EditText title = field("你最想完成的目标，例如：3个月通过N2 / 完成毕业设计", InputType.TYPE_CLASS_TEXT);
        Spinner category = spinner(new String[]{"考试学习","语言学习","编程技术","项目作品","健身运动","职业求职","通用目标"});
        EditText date = field("目标日期 YYYY-MM-DD，例如 2026-12-06", InputType.TYPE_CLASS_DATETIME);
        date.setFocusable(false);
        date.setOnClickListener(v -> pickDate(date));
        EditText baseline = field("你现在处于什么水平？", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        baseline.setMinLines(2);
        EditText why = field("为什么这个目标对你重要？", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        why.setMinLines(2);
        EditText daily = field("每天可投入分钟数，例如 90", InputType.TYPE_CLASS_NUMBER);
        daily.setText("90");
        Spinner priority = spinner(new String[]{"1 低","2","3 中","4","5 最高"}); priority.setSelection(2);
        Spinner time = spinner(new String[]{"早晨","上午","下午","晚间","灵活安排"}); time.setSelection(3);
        EditText capacity = field("你每天所有目标总共可投入多少分钟？", InputType.TYPE_CLASS_NUMBER);
        capacity.setText("150");

        addLabeled("你的称呼", name);
        addLabeled("目标名称", title);
        addLabeled("目标类型", category);
        addLabeled("目标日期", date);
        addLabeled("当前水平", baseline);
        addLabeled("目标意义", why);
        addLabeled("这个目标每天投入", daily);
        addLabeled("优先级", priority);
        addLabeled("偏好时间", time);
        addLabeled("每日总可用时间", capacity);

        Button start = new Button(this);
        start.setText("生成我的第一份行动计划"); start.setAllCaps(false);
        start.setOnClickListener(v -> {
            if (title.getText().toString().trim().isEmpty()) { toast("先写下一个具体目标"); return; }
            if (date.getText().toString().trim().isEmpty()) date.setText(LocalDate.now().plusMonths(3).toString());
            int dm = parseInt(daily.getText().toString(),90);
            int cap = parseInt(capacity.getText().toString(),150);
            store.setUserName(name.getText().toString());
            store.setDailyCapacity(cap);
            store.addGoal(title.getText().toString(), category.getSelectedItem().toString(), date.getText().toString(),
                    why.getText().toString(), baseline.getText().toString(), dm, priority.getSelectedItemPosition()+1,
                    time.getSelectedItem().toString());
            store.setOnboarded(true);
            ReminderScheduler.scheduleAll(this);
            showToday();
        });
        page.addView(start, Ui.cardParams(this));
    }

    private void showToday() {
        String date = new SimpleDateFormat("M月d日 EEEE", Locale.CHINA).format(new Date());
        String name = store.userName().isEmpty() ? "" : store.userName() + "，";
        shell("GrowthPilot · 今日", name + date + " · 把目标推进一点点", true);
        todayTasks = engine.buildTodayTasks();
        addCoachCard();
        addPrimaryGoalCard();
        addTodayProgressCard();
        addScheduleCard();
        if (todayTasks.isEmpty()) addEmptyGoalCard(); else for (TaskItem t : todayTasks) addTaskCard(t);
        addEndOfDayHint();
        persistTodayTotals();
    }

    private void addCoachCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"🧭 今日教练建议",18,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,engine.dailyCoachMessage(),14,Color.rgb(71,85,105),false));
        page.addView(c,Ui.cardParams(this));
    }

    private Goal primaryGoal() {
        List<Goal> gs = store.goals();
        if (gs.isEmpty()) return null;
        Collections.sort(gs, Comparator.comparingInt((Goal g)->g.priority).reversed());
        for (Goal g : gs) if (g.active) return g;
        return gs.get(0);
    }

    private void addPrimaryGoalCard() {
        Goal g = primaryGoal();
        if (g == null) return;
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"🎯 主目标：" + g.title,19,Color.rgb(15,23,42),true));
        int progress = engine.totalProgress(g);
        TextView big = Ui.text(this,"总攻克进度 " + progress + "%",28,Color.rgb(37,99,235),true);
        c.addView(big);
        ProgressBar pb = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100); pb.setProgress(progress);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,14));
        p.setMargins(0,Ui.dp(this,8),0,Ui.dp(this,10)); c.addView(pb,p);
        c.addView(Ui.text(this,"当前阶段：" + engine.currentPhase(g) + " · 阶段推进 " + g.phaseProgress + "%",14,Color.rgb(51,65,85),true));
        long left = engine.daysLeft(g);
        String d = left >= 0 ? "距离目标约 " + left + " 天" : "未设置有效目标日期";
        c.addView(Ui.text(this,d + " · 目标健康度 " + engine.healthScore(g) + "/100（" + engine.healthLabel(g) + "）",13,Color.rgb(100,116,139),false));
        GrowthMapView map = new GrowthMapView(this); map.setData(engine.phases(g),g.phaseIndex,g.phaseProgress);
        c.addView(map,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,135)));
        Button details = new Button(this); details.setText("查看完整目标地图"); details.setAllCaps(false); details.setOnClickListener(v->showGoals()); c.addView(details);
        page.addView(c,Ui.cardParams(this));
    }

    private void addTodayProgressCard() {
        int total = todayTasks.size(), done = 0;
        for (TaskItem t : todayTasks) if (store.isTaskDone(t.id)) done++;
        int percent = total == 0 ? 0 : done * 100 / total;
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"今日推进",18,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,percent + "%  ·  " + done + "/" + total + " 项",28,Color.rgb(37,99,235),true));
        ProgressBar pb = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100); pb.setProgress(percent); c.addView(pb,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,14)));
        c.addView(Ui.text(this,"🔥 连续执行 " + store.streak() + " 天  ·  ⏱ 今日专注 " + store.focusMinutesToday() + " 分钟  ·  Lv." + store.level(),13,Color.rgb(71,85,105),false));
        page.addView(c,Ui.cardParams(this));
    }


    private void addScheduleCard() {
        if (todayTasks.isEmpty()) return;
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"🗓 今日建议时间表",18,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,engine.suggestedSchedule(todayTasks),13,Color.rgb(71,85,105),false));
        page.addView(c,Ui.cardParams(this));
    }

    private void addTaskCard(TaskItem t) {
        boolean done = store.isTaskDone(t.id);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,(done?"✅ ":"⬜ ") + t.title,18,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,"目标：" + t.goalTitle + " · 预计 " + t.minutes + " 分钟",13,Color.rgb(100,116,139),false));
        if (done) {
            c.addView(Ui.text(this,"已完成：这一步已经计入今天的真实推进。",13,Color.rgb(22,101,52),true));
            Button undo = new Button(this); undo.setText("撤销本次完成"); undo.setAllCaps(false); undo.setOnClickListener(v->{store.undoTask(t); showToday();}); c.addView(undo);
        } else {
            Button focus = new Button(this); focus.setText("▶ 开始番茄专注"); focus.setAllCaps(false); focus.setOnClickListener(v->startFocus(t)); c.addView(focus);
            Button guide = new Button(this); guide.setText("查看详细步骤 / 验收标准"); guide.setAllCaps(false); guide.setOnClickListener(v->showTaskGuide(t)); c.addView(guide);
            Button complete = new Button(this); complete.setText("完成并反馈质量"); complete.setAllCaps(false); complete.setOnClickListener(v->completeTask(t)); c.addView(complete);
            Button stuck = new Button(this); stuck.setText("我卡住了"); stuck.setAllCaps(false); stuck.setOnClickListener(v->showStuck(t)); c.addView(stuck);
        }
        page.addView(c,Ui.cardParams(this));
    }

    private void startFocus(TaskItem t) {
        Intent i = new Intent(this, FocusActivity.class);
        i.putExtra("taskTitle",t.title); i.putExtra("taskId",t.id); i.putExtra("goalTitle",t.goalTitle);
        startActivity(i);
    }

    private void showTaskGuide(TaskItem t) {
        new AlertDialog.Builder(this)
                .setTitle("📘 " + t.title)
                .setMessage(t.guidance + "\n\n【忙碌时的最低版本】\n" + t.minimumAction)
                .setPositiveButton("开始专注",(d,w)->startFocus(t))
                .setNegativeButton("关闭",null)
                .show();
    }

    private void completeTask(TaskItem t) {
        Goal g = store.goalById(t.goalId);
        int before = g == null ? 0 : engine.totalProgress(g);
        new AlertDialog.Builder(this)
                .setTitle("这次完成质量怎么样？")
                .setMessage("正反馈必须对应真实推进，所以请按结果而不是心情选择。")
                .setPositiveButton("达到标准",(d,w)->recordCompletion(t,100,before))
                .setNeutralButton("超额完成",(d,w)->recordCompletion(t,115,before))
                .setNegativeButton("部分完成",(d,w)->recordCompletion(t,70,before))
                .show();
    }

    private void recordCompletion(TaskItem t, int quality, int before) {
        store.setTaskDone(t,quality);
        Goal afterGoal = store.goalById(t.goalId);
        int after = afterGoal == null ? before : engine.totalProgress(afterGoal);
        persistTodayTotals();
        String msg = "完成「" + t.title + "」\n\n" +
                "目标总进度：" + before + "% → " + after + "%\n" +
                "阶段推进：" + (afterGoal == null ? "-" : afterGoal.phaseProgress + "%") + "\n" +
                "获得经验值，继续累积真实成果。";
        new AlertDialog.Builder(this).setTitle("推进成功 🎉").setMessage(msg)
                .setPositiveButton("继续",(d,w)->showToday()).show();
    }

    private void showStuck(TaskItem t) {
        String[] reasons = {"不知道怎么开始","任务太难","今天没时间","没有动力","身体/精神疲劳","遇到具体技术问题"};
        new AlertDialog.Builder(this).setTitle("你卡在哪里？")
                .setItems(reasons,(d,which)->new AlertDialog.Builder(this)
                        .setTitle("马上这样处理")
                        .setMessage(engine.stuckAdvice(t,reasons[which]))
                        .setPositiveButton("做最低行动",(x,y)->startFocus(t))
                        .setNegativeButton("稍后",null).show()).show();
    }

    private void addEndOfDayHint() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"晚上只做 2 分钟复盘",17,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,"最有效动作 · 最大卡点 · 明天第一步。失败不是清零，而是给下一次计划提供数据。",13,Color.rgb(71,85,105),false));
        Button b = new Button(this); b.setText("去复盘"); b.setAllCaps(false); b.setOnClickListener(v->showReview()); c.addView(b);
        page.addView(c,Ui.cardParams(this));
    }

    private void addEmptyGoalCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"还没有可执行目标",18,Color.rgb(15,23,42),true));
        Button b = new Button(this); b.setText("创建目标"); b.setAllCaps(false); b.setOnClickListener(v->showGoalForm(false)); c.addView(b);
        page.addView(c,Ui.cardParams(this));
    }

    private void showGoals() {
        shell("目标攻克地图", "大目标 → 阶段 → 今日行动；每一步完成都会推进可视化进度", true);
        List<Goal> gs = store.goals();
        if (gs.isEmpty()) { addEmptyGoalCard(); return; }
        for (Goal g : gs) addGoalMapCard(g);
        Button add = new Button(this); add.setText("＋ 添加新目标"); add.setAllCaps(false); add.setOnClickListener(v->showGoalForm(false)); page.addView(add,Ui.cardParams(this));
        addProgressLogicCard();
    }

    private void addGoalMapCard(Goal g) {
        LinearLayout c = Ui.card(this);
        int total = engine.totalProgress(g);
        c.addView(Ui.text(this,"🎯 " + g.title,20,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,g.category + " · 优先级 " + g.priority + "/5 · " + g.preferredTime,12,Color.rgb(100,116,139),false));
        c.addView(Ui.text(this,"总攻克进度 " + total + "%",24,Color.rgb(37,99,235),true));
        ProgressBar p = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); p.setMax(100); p.setProgress(total);
        c.addView(p,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,14)));
        GrowthMapView map = new GrowthMapView(this); map.setData(engine.phases(g),g.phaseIndex,g.phaseProgress);
        c.addView(map,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,135)));
        c.addView(Ui.text(this,"当前：" + engine.currentPhase(g) + " · 阶段 " + g.phaseProgress + "%",14,Color.rgb(51,65,85),true));
        c.addView(Ui.text(this,"健康度 " + engine.healthScore(g) + "/100（" + engine.healthLabel(g) + "） · 当前水平：" + (g.baseline.isEmpty()?"未填写":g.baseline),13,Color.rgb(71,85,105),false));
        Button checkpoint = new Button(this); checkpoint.setText("阶段验收 / 解锁下一阶段"); checkpoint.setAllCaps(false); checkpoint.setOnClickListener(v->showCheckpoint(g)); c.addView(checkpoint);
        Button edit = new Button(this); edit.setText("编辑目标"); edit.setAllCaps(false); edit.setOnClickListener(v->showEditGoal(g)); c.addView(edit);
        page.addView(c,Ui.cardParams(this));
    }

    private void showCheckpoint(Goal g) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0);
        TextView hint = Ui.text(this,"当前阶段推进 " + g.phaseProgress + "%\n建议推进 ≥50% 再做验收。请提供一个真实结果，例如测试分数、作品、跑步数据、演示结果或他人反馈。",13,Color.rgb(71,85,105),false);
        EditText score = field("验证得分 0–100",InputType.TYPE_CLASS_NUMBER);
        EditText evidence = field("验证证据 / 结果",InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE); evidence.setMinLines(3);
        box.addView(hint); box.addView(score); box.addView(evidence);
        new AlertDialog.Builder(this).setTitle("阶段验收：" + engine.currentPhase(g)).setView(box)
                .setPositiveButton("提交验收",(d,w)->{
                    int s = parseInt(score.getText().toString(),0);
                    if (g.phaseProgress < 50) { toast("阶段推进还不足50%，先继续执行核心任务"); return; }
                    if (s < 70) { toast("本次未达到升级线。保留结果，针对弱点继续训练"); return; }
                    store.advancePhase(g.id,s,evidence.getText().toString());
                    new AlertDialog.Builder(this).setTitle("阶段解锁 🎉").setMessage("你已经通过验收。下一阶段的任务与指导会从今天起自动变化。")
                            .setPositiveButton("查看新阶段",(x,y)->showGoals()).show();
                }).setNegativeButton("取消",null).show();
    }

    private void addProgressLogicCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"进度为什么会前进？",17,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,"• 完成每日核心任务会推进当前阶段，但最多自动推进到 85%。\n• 阶段升级必须通过一次可验证的验收（结果/测试/作品/数据）。\n• 总进度由 5 个阶段组成，每阶段约 20%。\n• 这样避免“只打卡、不成长”的虚假进度。",13,Color.rgb(71,85,105),false));
        page.addView(c,Ui.cardParams(this));
    }

    private void showFocusHub() {
        shell("专注中心", "番茄不是为了计时，而是把最重要的目标推进一个可验证结果", true);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"今日专注 " + store.focusMinutesToday() + " 分钟",28,Color.rgb(37,99,235),true));
        c.addView(Ui.text(this,"累计专注 " + store.focusMinutesTotal() + " 分钟 · Lv." + store.level() + " · 距离下一级还差 " + store.xpToNext() + " XP",13,Color.rgb(71,85,105),false));
        Button free = new Button(this); free.setText("开始自由番茄"); free.setAllCaps(false); free.setOnClickListener(v->{
            Intent i = new Intent(this,FocusActivity.class); i.putExtra("taskTitle","自由专注"); i.putExtra("goalTitle","自主任务"); startActivity(i);
        }); c.addView(free); page.addView(c,Ui.cardParams(this));
        for (TaskItem t : engine.buildTodayTasks()) {
            if (!store.isTaskDone(t.id)) {
                LinearLayout tc = Ui.card(this);
                tc.addView(Ui.text(this,t.title,17,Color.rgb(15,23,42),true));
                tc.addView(Ui.text(this,t.goalTitle + " · 建议 " + t.minutes + " 分钟",12,Color.rgb(100,116,139),false));
                Button b = new Button(this); b.setText("用番茄推进这个任务"); b.setAllCaps(false); b.setOnClickListener(v->startFocus(t)); tc.addView(b);
                page.addView(tc,Ui.cardParams(this));
            }
        }
        LinearLayout rule = Ui.card(this);
        rule.addView(Ui.text(this,"专注规则",17,Color.rgb(15,23,42),true));
        rule.addView(Ui.text(this,"1. 开始前先写清这一轮的结果。\n2. 计时期间不切换任务。\n3. 结束后选择“完成 / 部分完成”，记录真实专注。\n4. 预计耗时和实际耗时长期对比，后续计划会更接近真实节奏。",13,Color.rgb(71,85,105),false));
        page.addView(rule,Ui.cardParams(this));
    }

    private void showReview() {
        shell("执行复盘", "复盘不是批评自己，而是让下一次计划更准确", true);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"今日 2 分钟复盘",20,Color.rgb(15,23,42),true));
        EditText best = field("今天最有效的动作是什么？",InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE); best.setText(store.review("best"));
        EditText blocker = field("最大卡点是什么？",InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE); blocker.setText(store.review("blocker"));
        EditText first = field("明天第一步是什么？",InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE); first.setText(store.review("first"));
        Spinner energy = spinner(new String[]{"1 很低","2 偏低","3 正常","4 良好","5 很好"}); energy.setSelection(Math.max(0,store.energyToday()-1));
        c.addView(best); c.addView(blocker); c.addView(first); c.addView(Ui.text(this,"今日精力",13,Color.rgb(71,85,105),true)); c.addView(energy);
        Button save = new Button(this); save.setText("保存复盘并影响后续计划"); save.setAllCaps(false); save.setOnClickListener(v->{
            store.saveDailyReview(best.getText().toString(),blocker.getText().toString(),first.getText().toString(),energy.getSelectedItemPosition()+1);
            toast("复盘已保存");
        }); c.addView(save); page.addView(c,Ui.cardParams(this));

        LinearLayout week = Ui.card(this);
        week.addView(Ui.text(this,"本周自动总结",19,Color.rgb(15,23,42),true));
        week.addView(Ui.text(this,"近7天平均完成率：" + store.recentAverageCompletion(7) + "%\n累计专注：" + store.focusMinutesTotal() + " 分钟\n当前连续执行：" + store.streak() + " 天\n\n下周原则：只保留真正推进目标的核心动作，低完成率时主动降载，高完成率时增加验证难度。",13,Color.rgb(71,85,105),false));
        page.addView(week,Ui.cardParams(this));
    }

    private void showStats() {
        shell("成长数据", "看趋势，不被单日状态绑架", true);
        LinearLayout m = Ui.card(this);
        m.addView(Ui.text(this,"Lv." + store.level() + " · " + store.xp() + " XP",28,Color.rgb(37,99,235),true));
        m.addView(Ui.text(this,"连续执行 " + store.streak() + " 天 · 近7天完成率 " + store.recentAverageCompletion(7) + "% · 累计专注 " + store.focusMinutesTotal() + " 分钟",13,Color.rgb(71,85,105),false));
        page.addView(m,Ui.cardParams(this));
        LinearLayout bars = Ui.card(this); bars.addView(Ui.text(this,"最近7天完成趋势",18,Color.rgb(15,23,42),true)); bars.addView(new WeeklyBarsView(this),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,180))); page.addView(bars,Ui.cardParams(this));
        for (Goal g : store.goals()) {
            LinearLayout c = Ui.card(this); c.addView(Ui.text(this,g.title,17,Color.rgb(15,23,42),true));
            c.addView(Ui.text(this,"总进度 " + engine.totalProgress(g) + "% · 阶段 " + engine.currentPhase(g) + " " + g.phaseProgress + "% · 健康度 " + engine.healthScore(g) + "/100",13,Color.rgb(71,85,105),false));
            ProgressBar p = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); p.setMax(100); p.setProgress(engine.totalProgress(g)); c.addView(p,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(this,12)));
            page.addView(c,Ui.cardParams(this));
        }
    }

    private void showSettings() {
        shell("设置", "计划强度、提醒、目标和数据", true);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"每日总可用时间",18,Color.rgb(15,23,42),true));
        EditText cap = field("分钟",InputType.TYPE_CLASS_NUMBER); cap.setText(String.valueOf(store.dailyCapacity())); c.addView(cap);
        Button save = new Button(this); save.setText("保存时间预算"); save.setAllCaps(false); save.setOnClickListener(v->{store.setDailyCapacity(parseInt(cap.getText().toString(),150)); toast("已保存，今日计划会按新预算重排");}); c.addView(save);
        page.addView(c,Ui.cardParams(this));

        addReminderSettings();

        LinearLayout goals = Ui.card(this);
        goals.addView(Ui.text(this,"目标管理",18,Color.rgb(15,23,42),true));
        Button add = new Button(this); add.setText("＋ 添加目标"); add.setAllCaps(false); add.setOnClickListener(v->showGoalForm(false)); goals.addView(add);
        Button list = new Button(this); list.setText("查看 / 编辑所有目标"); list.setAllCaps(false); list.setOnClickListener(v->showGoals()); goals.addView(list);
        page.addView(goals,Ui.cardParams(this));

        LinearLayout data = Ui.card(this);
        data.addView(Ui.text(this,"数据与隐私",18,Color.rgb(15,23,42),true));
        data.addView(Ui.text(this,"当前 Beta 版默认只把目标、打卡、复盘和专注数据保存在你的手机本地，不上传服务器。建议定期导出备份。",13,Color.rgb(71,85,105),false));
        Button export = new Button(this); export.setText("复制备份数据"); export.setAllCaps(false); export.setOnClickListener(v->copyBackup()); data.addView(export);
        Button imp = new Button(this); imp.setText("从备份恢复"); imp.setAllCaps(false); imp.setOnClickListener(v->importBackup()); data.addView(imp);
        page.addView(data,Ui.cardParams(this));
    }

    private void addReminderSettings() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this,"系统提醒",18,Color.rgb(15,23,42),true));
        c.addView(Ui.text(this,"默认：早晨看计划、晚间执行提醒、睡前复盘。ColorOS 等系统还需要允许通知和后台活动。",13,Color.rgb(71,85,105),false));
        addTimeButton(c,"早晨计划提醒","morning",7,30);
        addTimeButton(c,"晚间执行提醒","action",19,30);
        addTimeButton(c,"睡前复盘提醒","review",22,30);
        Button test = new Button(this); test.setText("发送测试通知"); test.setAllCaps(false); test.setOnClickListener(v->AlarmReceiver.sendTest(this)); c.addView(test);
        page.addView(c,Ui.cardParams(this));
    }

    private void addTimeButton(LinearLayout c, String label, String key, int defH, int defM) {
        int h = store.prefs().getInt(key+"_hour",defH), m = store.prefs().getInt(key+"_min",defM);
        Button b = new Button(this); b.setAllCaps(false); b.setText(label + "  " + two(h) + ":" + two(m));
        b.setOnClickListener(v->new TimePickerDialog(this,(view,hour,minute)->{
            store.prefs().edit().putInt(key+"_hour",hour).putInt(key+"_min",minute).apply();
            ReminderScheduler.scheduleAll(this); showSettings();
        },h,m,true).show());
        c.addView(b);
    }

    private void showGoalForm(boolean first) {
        shell("创建新目标", "目标越具体，系统越容易给出可执行的下一步", true);
        EditText title = field("目标名称",InputType.TYPE_CLASS_TEXT);
        Spinner category = spinner(new String[]{"考试学习","语言学习","编程技术","项目作品","健身运动","职业求职","通用目标"});
        EditText date = field("目标日期",InputType.TYPE_CLASS_DATETIME); date.setFocusable(false); date.setOnClickListener(v->pickDate(date));
        EditText baseline = field("当前水平",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); baseline.setMinLines(2);
        EditText why = field("为什么重要",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); why.setMinLines(2);
        EditText daily = field("每天投入分钟",InputType.TYPE_CLASS_NUMBER); daily.setText("60");
        Spinner priority = spinner(new String[]{"1 低","2","3 中","4","5 最高"}); priority.setSelection(2);
        Spinner time = spinner(new String[]{"早晨","上午","下午","晚间","灵活安排"}); time.setSelection(4);
        addLabeled("目标名称",title); addLabeled("类型",category); addLabeled("截止日期",date); addLabeled("当前水平",baseline); addLabeled("为什么重要",why); addLabeled("每日投入",daily); addLabeled("优先级",priority); addLabeled("偏好时间",time);
        Button save = new Button(this); save.setText("创建并生成计划"); save.setAllCaps(false); save.setOnClickListener(v->{
            if (title.getText().toString().trim().isEmpty()) {toast("目标名称不能为空");return;}
            if (date.getText().toString().isEmpty()) date.setText(LocalDate.now().plusMonths(3).toString());
            store.addGoal(title.getText().toString(),category.getSelectedItem().toString(),date.getText().toString(),why.getText().toString(),baseline.getText().toString(),parseInt(daily.getText().toString(),60),priority.getSelectedItemPosition()+1,time.getSelectedItem().toString());
            showGoals();
        }); page.addView(save,Ui.cardParams(this));
    }

    private void showEditGoal(Goal g) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);
        EditText title = field("目标名称",InputType.TYPE_CLASS_TEXT); title.setText(g.title);
        EditText date = field("目标日期",InputType.TYPE_CLASS_DATETIME); date.setText(g.targetDate); date.setFocusable(false); date.setOnClickListener(v->pickDate(date));
        EditText baseline = field("当前水平",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); baseline.setText(g.baseline);
        EditText why = field("为什么重要",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); why.setText(g.why);
        EditText daily = field("每日投入分钟",InputType.TYPE_CLASS_NUMBER); daily.setText(String.valueOf(g.dailyMinutes));
        box.addView(title);box.addView(date);box.addView(baseline);box.addView(why);box.addView(daily);
        new AlertDialog.Builder(this).setTitle("编辑目标").setView(box)
                .setPositiveButton("保存",(d,w)->{g.title=title.getText().toString();g.targetDate=date.getText().toString();g.baseline=baseline.getText().toString();g.why=why.getText().toString();g.dailyMinutes=parseInt(daily.getText().toString(),g.dailyMinutes);store.updateGoal(g);showGoals();})
                .setNeutralButton("停用/启用",(d,w)->{g.active=!g.active;store.updateGoal(g);showGoals();})
                .setNegativeButton("取消",null).show();
    }

    private void copyBackup() {
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("GrowthPilot Backup",store.exportJson()));
        toast("备份数据已复制到剪贴板");
    }

    private void importBackup() {
        EditText e = field("粘贴 GrowthPilot 备份 JSON",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); e.setMinLines(7);
        new AlertDialog.Builder(this).setTitle("恢复备份").setView(e)
                .setPositiveButton("恢复",(d,w)->{if(store.importJson(e.getText().toString())){toast("恢复成功");showToday();}else toast("备份格式无效");})
                .setNegativeButton("取消",null).show();
    }

    private void persistTodayTotals() {
        int done=0; for(TaskItem t:todayTasks) if(store.isTaskDone(t.id)) done++; store.saveTodayTotals(todayTasks.size(),done);
    }

    private void addLabeled(String label, View v) {
        LinearLayout c = Ui.card(this); c.addView(Ui.text(this,label,14,Color.rgb(51,65,85),true)); c.addView(v); page.addView(c,Ui.cardParams(this));
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setHint(hint); e.setInputType(type); e.setTextSize(15); e.setPadding(Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10)); return e;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this); ArrayAdapter<String> a = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values); s.setAdapter(a); return s;
    }

    private void pickDate(EditText target) {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this,(v,y,m,d)->target.setText(String.format(Locale.getDefault(),"%04d-%02d-%02d",y,m+1,d)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private int parseInt(String s,int def) { try{return Integer.parseInt(s.trim());}catch(Exception e){return def;} }
    private String two(int n) { return String.format(Locale.getDefault(),"%02d",n); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
