package com.growthpilot.universal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class GrowthMapView extends View {
    private String[] labels = {"阶段1","阶段2","阶段3","阶段4","阶段5"};
    private int current = 0;
    private int phaseProgress = 0;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GrowthMapView(Context c) { super(c); setMinimumHeight(dp(130)); }

    public void setData(String[] labels, int current, int phaseProgress) {
        if (labels != null && labels.length == 5) this.labels = labels;
        this.current = Math.max(0, Math.min(4, current));
        this.phaseProgress = Math.max(0, Math.min(100, phaseProgress));
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int y = dp(44);
        int left = dp(34), right = w - dp(34);
        float gap = (right - left) / 4f;

        p.setStrokeWidth(dp(6));
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(Color.rgb(203,213,225));
        canvas.drawLine(left, y, right, y, p);

        float completedX = left + gap * current + gap * (phaseProgress / 100f);
        if (current == 4) completedX = left + gap * 4f * Math.min(1f, (current * 20 + phaseProgress / 5f) / 100f);
        completedX = Math.max(left, Math.min(right, completedX));
        p.setColor(Color.rgb(37,99,235));
        canvas.drawLine(left, y, completedX, y, p);

        for (int i = 0; i < 5; i++) {
            float x = left + gap * i;
            boolean done = i < current;
            boolean now = i == current;
            p.setStyle(Paint.Style.FILL);
            p.setColor(done ? Color.rgb(34,197,94) : now ? Color.rgb(37,99,235) : Color.rgb(226,232,240));
            canvas.drawCircle(x, y, dp(now ? 11 : 9), p);
            if (done) {
                p.setColor(Color.WHITE); p.setStrokeWidth(dp(2)); p.setStyle(Paint.Style.STROKE);
                canvas.drawLine(x-dp(4), y, x-dp(1), y+dp(4), p);
                canvas.drawLine(x-dp(1), y+dp(4), x+dp(5), y-dp(4), p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(10));
            p.setColor(Color.rgb(71,85,105));
            p.setTextAlign(Paint.Align.CENTER);
            String label = labels[i];
            if (label.length() > 6) label = label.substring(0,6);
            canvas.drawText(label, x, y + dp(32), p);
        }

        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(dp(12));
        p.setColor(Color.rgb(15,23,42));
        canvas.drawText("当前阶段推进 " + phaseProgress + "%", left, dp(112), p);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
