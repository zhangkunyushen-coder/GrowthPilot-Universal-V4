package com.growthpilot.universal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.Calendar;

public class WeeklyBarsView extends View {
    private final AppStore store;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public WeeklyBarsView(Context c) {
        super(c);
        store = new AppStore(c);
        setMinimumHeight(dp(170));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        int baseY = h - dp(28);
        int top = dp(20);
        int left = dp(20);
        float gap = (w - dp(40)) / 7f;
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -6);
        String[] labels = {"日","一","二","三","四","五","六"};
        for (int i = 0; i < 7; i++) {
            int rate = store.completionRateForDay(c);
            int value = rate < 0 ? 0 : rate;
            float x = left + gap * i + gap * 0.2f;
            float bw = gap * 0.6f;
            float bh = (baseY - top) * value / 100f;
            p.setColor(Color.rgb(226,232,240));
            canvas.drawRoundRect(x, top, x+bw, baseY, dp(6), dp(6), p);
            p.setColor(value >= 80 ? Color.rgb(34,197,94) : value >= 50 ? Color.rgb(37,99,235) : Color.rgb(148,163,184));
            canvas.drawRoundRect(x, baseY-bh, x+bw, baseY, dp(6), dp(6), p);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(10));
            p.setColor(Color.rgb(71,85,105));
            canvas.drawText(labels[c.get(Calendar.DAY_OF_WEEK)-1], x+bw/2, h-dp(8), p);
            c.add(Calendar.DAY_OF_YEAR, 1);
        }
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
