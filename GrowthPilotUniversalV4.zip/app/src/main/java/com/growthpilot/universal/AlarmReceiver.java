package com.growthpilot.universal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.List;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "growthpilot_universal_daily";

    @Override public void onReceive(Context c, Intent intent) {
        String type = intent == null ? "review" : intent.getStringExtra("type");
        if (type == null) type = "review";
        AppStore store = new AppStore(c);
        PlanEngine engine = new PlanEngine(c);
        List<TaskItem> tasks = engine.buildTodayTasks();
        int done=0; for(TaskItem t:tasks) if(store.isTaskDone(t.id)) done++;
        String title, text;
        int id;
        if (type.equals("morning")) {
            title="🎯 今天把目标推进一点";
            text = tasks.isEmpty()?"先创建一个目标，让 GrowthPilot 生成今天的行动。":"今天有 " + tasks.size() + " 项核心行动。先做最重要的一项。";
            id=401;
        } else if (type.equals("action")) {
            title="⏱ 现在适合一个专注块";
            text = done + "/" + tasks.size() + " 已完成。打开 GrowthPilot，用 25 分钟推进最重要任务。";
            id=402;
        } else {
            int left=Math.max(0,tasks.size()-done);
            title = left>0 ? "📝 今天还有 " + left + " 项未推进" : "✅ 今日核心任务已完成";
            text = "做2分钟复盘：最有效动作、最大卡点、明天第一步。";
            id=403;
        }
        notify(c,id,title,text);
    }

    public static void sendTest(Context c) { notify(c,499,"GrowthPilot 测试通知","通知正常。之后会按你设置的时间提醒计划、执行和复盘。"); }

    private static void notify(Context c, int id, String title, String text) {
        createChannel(c);
        Intent open = new Intent(c,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT>=26 ? new Notification.Builder(c,CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm!=null) nm.notify(id,b.build());
    }

    public static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(CHANNEL,"GrowthPilot 每日提醒",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("目标计划、专注执行与复盘提醒");
            NotificationManager nm=c.getSystemService(NotificationManager.class); if(nm!=null) nm.createNotificationChannel(ch);
        }
    }
}
